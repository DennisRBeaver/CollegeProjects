First Project
Dennis Beaver,
Austen Lowder

Project summary:
This project is about taking username, time and revisions from a wiki api link. Where the user can put anyname they want and it will collect the JSON data from the api link and format it in a way that is readable to the user. It will provide whether or not their are redirects and whether it errors out or not. This will allow for users to search any name they want and find the most recent 27 changes and what users did them. Next on the list was to add a GUI interface for the project to allow users to see it through console or GUI

Warnings suppressed include gradle 8.0 deprecation, reasoning: This warning is here regardless if we update our gradle version or not.

Instructions:
To run the program go to the "main" class and run it. After that type in whatever name you wish and your data will be ruturned to you!
Or you click on the most righthand side the word "gradle" then FirstProjectAD -> tasks -> application -> run. Then enter whatever search you want. It will return your data!
