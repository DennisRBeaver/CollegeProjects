package finals.project.ui.login

data class LoggedInUserView(
        val displayName: String
)