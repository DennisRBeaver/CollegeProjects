<template>
  <div class="page-container">
    <div class="content-container">
      <div class="column">
        <div class="header">
          <h2 class="page-heading">Overall Money Saving Tips</h2>
        </div>
        <div class="links-container">
          <ul>
            <li>
              <a
                href="https://moneymentors.ca/money-tips/8-tips-to-avoid-spending-money-on-wants/"
                >How to Stop Spending Money</a
              >
              <p>
                This article provides some basic tips and tricks on how you can
                save money and still have a good time, ranging from sales tips,
                savings goals, and accountability.
              </p>
            </li>
            <li>
              <a
                href="https://www.pnc.com/insights/personal-finance/save/how-to-stop-spending-money.html"
                >Top 10 Tips to Stay in Control of you Finances</a
              >
              <p>
                This article by PNC banking provides a list of tips to help you
                in the process of avoiding those unncessary purchases, with
                information on budgeting, and some things to avoid.
              </p>
            </li>
            <li>
              <a
                href="https://resources.depaul.edu/financial-fitness/tackle-overspending/Pages/solutions-for-overspending.aspx"
                >Solutions for Overspending</a
              >
              <p>
                This article written by DePaul lists some serious (and some
                rather ammusing) tips on how you can save money, with tips on
                how to identify needs versus wants.
              </p>
            </li>
          </ul>
        </div>
      </div>

      <div class="column">
        <div class="header">
          <h2 class="page-heading">Cutting Unnecessary Spending</h2>
        </div>
        <div class="links-container">
          <ul>
            <li>
              <a
                href="https://www.unbiased.co.uk/discover/personal-finance/budgeting/mindful-spending-how-to-stop-spending-money-on-unnecessary-things"
                >Mindful Spending</a
              >
              <p>
                This article gives a list of some of the classic pitfalls people
                stumble into on their money saving journey, read this for some
                things to look out for.
              </p>
            </li>
            <li>
              <a
                href="https://www.mind.org.uk/information-support/tips-for-everyday-living/money-and-mental-health/the-link-between-money-and-mental-health/#:~:text=Overspending%20can%20happen%20for%20different,or%20make%20impulsive%20financial%20decisions."
                >Mental Health and Money</a
              >
              <p>
                This article takes a look at the mental health side of money
                spending habits. While this article might not be relevant to
                everyone, it certainly is for those who have struggle with
                financial abuse, or frequently spend money to make themselves
                feel better.
              </p>
            </li>
            <li>
              <a
                href="https://merrickbank.com/Learn/Budgeting/5-Ways-to-Avoid-Unnecessary-Spending"
                >5 Ways to Avoid Unnecessary Spending</a
              >
              <p>
                This article by Merrick Bank gives a short list of tricks to
                avoid purchasing unncessary things such as fast food or other
                impulse buys.
              </p>
            </li>
          </ul>
        </div>
      </div>

      <div class="column">
        <div class="header">
          <h2 class="page-heading">Good Budgeting Habits</h2>
        </div>
        <div class="links-container">
          <ul>
            <li>
              <a
                href="https://www.unfcu.org/financial-wellness/50-30-20-rule/#:~:text=The%2050-30-20%20rule%20recommends%20putting%2050%25%20of,closer%20look%20at%20each%20category."
                >50-30-20</a
              >
              <p>
                This article helps to set a good budgeting habit with dedicated
                amounts for needs, wants, and goals. It also provides context on
                what should typically be considered a need versus a want.
              </p>
            </li>
            <li>
              <a
                href="https://www.discover.com/personal-loans/resources/consolidate-debt/good-financial-habits/"
                >9 Good Money Habits</a
              >
              <p>
                This article by Discover banking provides some good tips on how
                you can budget and stay on top of your finances. The article
                also lists some good advice on ways to financially plan for the
                unexpected.
              </p>
            </li>
            <li>
              <a
                href="https://bettermoneyhabits.bankofamerica.com/en/saving-budgeting/ways-to-save-money"
                >8 Simple Ways to Save</a
              >
              <p>
                This article by Bank of America gives a few good ways of cutting
                down on spending and curating a budget, as well as providing
                some solid resources for ways to automate your money saving
                journey.
              </p>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.page-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
}

.content-container {
  display: flex;
  justify-content: space-between;
}

.column {
  width: calc(33.33% - 20px);
}

.header {
  background-color: #053505;
  color: #f0f8ff;
  border-radius: 5px;
  padding: 10px;
  margin-bottom: 20px;
  text-align: center;
}

.page-heading {
  font-size: 1.5rem;
}

.links-container {
  padding: 0 10px;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  margin-bottom: 10px;
}

a {
  text-decoration: none;
  color: #006400;
  font-weight: bold;
}

a:hover {
  text-decoration: underline;
}
</style>
