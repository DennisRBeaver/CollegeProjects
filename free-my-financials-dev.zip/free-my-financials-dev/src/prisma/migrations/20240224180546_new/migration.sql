-- DropIndex
DROP INDEX "Budget_id_idx";
