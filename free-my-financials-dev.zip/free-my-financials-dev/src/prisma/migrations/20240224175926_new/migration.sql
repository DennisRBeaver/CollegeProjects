-- CreateIndex
CREATE INDEX "Budget_id_idx" ON "Budget"("id");
