/* v8 ignore start */
<template>
  <div>
    <FHeader />
    <UContainer>
      <slot />
    </UContainer>
    <UNotifications />
  </div>
</template>
