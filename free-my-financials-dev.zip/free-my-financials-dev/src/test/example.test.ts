import { test, expect } from 'vitest'

test('basic laws of math are still in effect', () => {
  expect(1 + 1).toBe(2)
})
