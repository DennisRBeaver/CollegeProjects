<template>
  <div>
    <NuxtLayout name="main">
      <NuxtPage />
    </NuxtLayout>
  </div>
</template>
